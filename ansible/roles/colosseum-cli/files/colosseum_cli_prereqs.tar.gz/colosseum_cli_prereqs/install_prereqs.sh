#!/bin/bash

python3 pip-9.0.1-py2.py3-none-any.whl/pip install --no-index pip-9.0.1-py2.py3-none-any.whl
pip3 install appdirs-1.4.3-py2.py3-none-any.whl
pip3 install pyparsing-2.2.0-py2.py3-none-any.whl
pip3 install packaging-16.8-py2.py3-none-any.whl
pip3 install pbr-2.0.0-py2.py3-none-any.whl
pip3 install stevedore-1.21.0-py2.py3-none-any.whl
pip3 install six-1.10.0-py2.py3-none-any.whl
pip3 install cmd2-0.7.0-cp34-none-any.whl 
pip3 install prettytable-0.7.2-cp34-none-any.whl
pip3 install PyYAML-3.12-cp34-cp34m-linux_x86_64.whl
pip3 install cliff-2.4.0-cp34-none-any.whl
pip3 install setuptools-34.3.2-py2.py3-none-any.whl

